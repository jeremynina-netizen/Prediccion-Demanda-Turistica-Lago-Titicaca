# 🏔️ Predicción de la Demanda Turística del Lago Titicaca

Sistema inteligente basado en **Machine Learning** para predecir la afluencia diaria de turistas al Lago Titicaca (Puno, Perú), como apoyo a la planificación de operadores turísticos y autoridades regionales.

**Curso:** Introducción a la Inteligencia Artificial
**Autor:** Jeremy Rodrigo Nina Arias — Código 261232

---

## 📌 Descripción del proyecto

El turismo hacia el Lago Titicaca (Islas de los Uros, Taquile, Amantaní) varía fuertemente según la temporada, el clima y las festividades regionales, lo que dificulta la planificación de embarcaciones, personal y recursos. Este proyecto entrena y compara tres algoritmos de Machine Learning (**Random Forest**, **Gradient Boosting** y **XGBoost**) para predecir el número de turistas por día, y despliega el mejor modelo en una aplicación web interactiva construida con **Streamlit**.

## 🎯 Objetivo

Predecir la demanda turística diaria del Lago Titicaca a partir de variables temporales, climáticas y de festividad, con el fin de apoyar la planificación eficiente de recursos turísticos.

## 🗂️ Estructura del repositorio

```
prediccion-turismo-titicaca/
├── README.md                      # Este archivo
├── requirements.txt                # Dependencias del proyecto
├── notebook_colab.py               # Código completo de entrenamiento (Google Colab)
├── app_streamlit.py                # Aplicación web de predicción
├── data/
│   └── turismo_titicaca.csv        # Dataset utilizado (histórico simulado 2019-2024)
├── modelo/
│   └── modelo_xgboost.pkl          # Modelo entrenado serializado (se genera al ejecutar el notebook)
└── img/
    ├── comparacion_metricas.png
    ├── real_vs_predicho.png
    ├── serie_temporal_2024.png
    ├── importancia_variables.png
    ├── estacionalidad_mensual.png
    ├── diagrama_flujo.png
    └── arquitectura_modelo.png
```

## 🧠 Modelos evaluados

| Modelo | MAE (turistas/día) | RMSE | R² |
|---|---|---|---|
| Random Forest | 94.4 | 125.4 | 0.837 |
| Gradient Boosting | 93.4 | 121.2 | 0.847 |
| **XGBoost (seleccionado)** | **91.6** | **119.1** | **0.853** |

XGBoost fue seleccionado como modelo de producción por obtener el mejor desempeño en las tres métricas evaluadas sobre el conjunto de prueba (año 2024, no visto durante el entrenamiento).

## ⚙️ Variables utilizadas

`año`, `mes`, `día de la semana`, `fin de semana (0/1)`, `festividad (0/1)`, `temporada (alta/media/baja)`, `temperatura (°C)`, `precipitación (mm)` → predicen `turistas por día`.

## 🚀 Instrucciones de ejecución

### 1. Entrenamiento del modelo (Google Colab)

1. Abre [Google Colab](https://colab.research.google.com/) y crea un notebook nuevo.
2. Copia el contenido de `notebook_colab.py` en las celdas del notebook (las celdas están delimitadas con `# %%`).
3. Ejecuta todas las celdas en orden (`Entorno de ejecución` → `Ejecutar todas`).
4. Al finalizar, se generará el archivo `modelo_xgboost.pkl`. Descárgalo con:
   ```python
   from google.colab import files
   files.download("modelo_xgboost.pkl")
   ```
5. Coloca el archivo descargado dentro de la carpeta `modelo/` de este repositorio (o junto a `app_streamlit.py`).

### 2. Ejecución local de la aplicación Streamlit

```bash
# 1. Clonar el repositorio
git clone https://github.com/<tu-usuario>/prediccion-turismo-titicaca.git
cd prediccion-turismo-titicaca

# 2. Crear un entorno virtual (opcional pero recomendado)
python -m venv venv
source venv/bin/activate      # En Windows: venv\Scripts\activate

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Colocar modelo_xgboost.pkl en la misma carpeta que app_streamlit.py

# 5. Ejecutar la aplicación
streamlit run app_streamlit.py
```

La aplicación se abrirá automáticamente en `http://localhost:8501`.

> Si `modelo_xgboost.pkl` no está presente, la aplicación entrena automáticamente un modelo de respaldo simplificado solo para fines de demostración.

## 📊 Métricas de evaluación utilizadas

- **MAE** (Error Absoluto Medio): error promedio en número de turistas.
- **RMSE** (Raíz del Error Cuadrático Medio): penaliza más los errores grandes.
- **R²** (Coeficiente de determinación): porcentaje de variabilidad explicada por el modelo.

## ⚠️ Limitaciones

- La variable objetivo (número de turistas) es una simulación estadísticamente informada, ya que no existe un registro público consolidado del conteo diario real de visitantes.
- El modelo no incluye variables macroeconómicas (tipo de cambio, vuelos programados) ni eventos extraordinarios no calendarizados.
- Antes de un uso operativo real, se recomienda reentrenar el modelo con datos administrativos reales de capitanía de puerto.

## 📚 Herramientas utilizadas

Python 3.11 · Pandas · NumPy · Scikit-Learn · XGBoost · Matplotlib · Streamlit · Google Colab · Joblib

## 📄 Licencia

Proyecto académico desarrollado para el curso de Introducción a la Inteligencia Artificial. Uso educativo.
