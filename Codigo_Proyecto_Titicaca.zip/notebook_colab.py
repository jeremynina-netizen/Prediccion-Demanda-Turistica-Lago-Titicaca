# -*- coding: utf-8 -*-
"""
============================================================================
 SISTEMA INTELIGENTE PARA LA PREDICCIÓN DE LA DEMANDA TURÍSTICA
 DEL LAGO TITICACA MEDIANTE MACHINE LEARNING
============================================================================
Autor: Jeremy Rodrigo Nina Arias (código 261232)
Curso: Introducción a la Inteligencia Artificial

Este script está organizado en celdas (marcadas con "# %%") pensadas para
ejecutarse directamente en Google Colab. Puede copiarse celda por celda en
un notebook (.ipynb) nuevo, o subirse tal cual y abrirse con la extensión
"Jupytext" / "Open in Colab" de GitHub.

Para ejecutarlo en Colab:
1. Sube este archivo o pégalo en un nuevo notebook.
2. Ejecuta las celdas en orden (Entorno de ejecución > Ejecutar todas).
3. Si trabajas con tus propios datos reales, reemplaza la celda de
   "Generación del dataset simulado" por la carga de tu CSV real
   (pd.read_csv("tu_archivo.csv")).
============================================================================
"""

# %% [1] INSTALACIÓN DE DEPENDENCIAS (solo necesario en Colab la primera vez)
# ----------------------------------------------------------------------------
# En Google Colab, descomenta la siguiente línea para instalar xgboost,
# que no viene preinstalado por defecto:
# !pip install xgboost --quiet

# %% [2] IMPORTACIÓN DE LIBRERÍAS
# ----------------------------------------------------------------------------
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib

from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

np.random.seed(42)  # Reproducibilidad de resultados

print("Librerías cargadas correctamente.")

# %% [3] GENERACIÓN DEL DATASET SIMULADO (reemplazar por datos reales si se dispone de ellos)
# ----------------------------------------------------------------------------
# NOTA METODOLÓGICA:
# No existe un registro público, unificado y digitalizado del conteo diario
# de turistas por embarcadero del Lago Titicaca. Por ello, este proyecto
# construye un dataset SIMULADO pero ESTADÍSTICAMENTE INFORMADO, calibrado
# con los patrones de estacionalidad, festividades, clima y el choque de la
# pandemia de COVID-19 reportados por fuentes oficiales (MINCETUR, SENAMHI,
# DIRCETUR Puno). Si se dispone de datos reales (por ejemplo, entregados por
# la capitanía de puerto de Puno), esta celda debe reemplazarse por:
#     df = pd.read_csv("turismo_titicaca_real.csv", parse_dates=["fecha"])

fechas = pd.date_range(start="2019-01-01", end="2024-12-31", freq="D")
n = len(fechas)
df = pd.DataFrame({"fecha": fechas})
df["anio"] = df["fecha"].dt.year
df["mes"] = df["fecha"].dt.month
df["dia_semana"] = df["fecha"].dt.dayofweek
df["es_fin_semana"] = df["dia_semana"].isin([5, 6]).astype(int)

# Estacionalidad: temporada alta (jun-ago) y repunte de fin de año
estacionalidad = {1: 0.85, 2: 0.55, 3: 0.55, 4: 0.60, 5: 0.70, 6: 0.95,
                   7: 1.15, 8: 1.10, 9: 0.85, 10: 0.75, 11: 0.75, 12: 1.05}
df["factor_estacional"] = df["mes"].map(estacionalidad)

# Festividades regionales relevantes de Puno
festividades = {
    (2, 2): "Virgen de la Candelaria", (2, 3): "Virgen de la Candelaria",
    (2, 4): "Virgen de la Candelaria", (2, 5): "Virgen de la Candelaria",
    (7, 28): "Fiestas Patrias", (7, 29): "Fiestas Patrias",
    (11, 5): "Aniversario de Puno", (12, 24): "Navidad",
    (12, 25): "Navidad", (12, 31): "Fin de Año",
}
df["festividad"] = df.apply(lambda r: festividades.get((r["mes"], r["fecha"].day), "Ninguna"), axis=1)
df["es_festividad"] = (df["festividad"] != "Ninguna").astype(int)

# Variables climáticas simuladas, correlacionadas con la estación (SENAMHI)
temp_base = {1: 9.5, 2: 9.3, 3: 9.0, 4: 8.0, 5: 5.5, 6: 3.0,
             7: 2.5, 8: 4.0, 9: 6.5, 10: 8.5, 11: 9.5, 12: 9.8}
df["temperatura_c"] = df["mes"].map(temp_base) + np.random.normal(0, 1.3, n)
prob_lluvia = {1: 0.55, 2: 0.55, 3: 0.45, 4: 0.20, 5: 0.05, 6: 0.02, 7: 0.02,
               8: 0.03, 9: 0.08, 10: 0.15, 11: 0.25, 12: 0.45}
df["probabilidad_lluvia"] = df["mes"].map(prob_lluvia)
df["precipitacion_mm"] = np.where(np.random.rand(n) < df["probabilidad_lluvia"],
                                   np.random.gamma(2, 4, n), 0.0)

# Choque estructural COVID-19 y recuperación gradual (patrón real de Puno)
def factor_covid(fecha):
    if fecha < pd.Timestamp("2020-03-16"): return 1.0
    if fecha < pd.Timestamp("2020-10-01"): return 0.03
    if fecha < pd.Timestamp("2021-10-01"): return 0.15
    if fecha < pd.Timestamp("2022-06-01"): return 0.55
    if fecha < pd.Timestamp("2023-01-01"): return 0.80
    return 1.0
df["factor_covid"] = df["fecha"].apply(factor_covid)
df["tendencia"] = 1 + 0.00006 * (df["fecha"] - fechas[0]).dt.days

# Construcción de la variable objetivo (turistas por día)
base = 850
ruido = np.random.normal(1, 0.12, n)
demanda = (base * df["factor_estacional"] * df["tendencia"] * df["factor_covid"]
           * (1 + 0.35 * df["es_fin_semana"]) * (1 + 0.9 * df["es_festividad"]) * ruido)
demanda = demanda * (1 - 0.15 * (df["precipitacion_mm"] > 15).astype(int))
df["turistas"] = np.clip(demanda, 20, None).round().astype(int)

temporada_map = {1: "Alta", 2: "Baja", 3: "Baja", 4: "Baja", 5: "Media", 6: "Alta",
                  7: "Alta", 8: "Alta", 9: "Media", 10: "Media", 11: "Media", 12: "Alta"}
df["temporada"] = df["mes"].map(temporada_map)

df = df[["fecha", "anio", "mes", "dia_semana", "es_fin_semana", "temporada",
         "festividad", "es_festividad", "temperatura_c", "precipitacion_mm", "turistas"]]

print(f"Dataset generado con {len(df)} registros diarios (2019-2024).")
df.head()

# %% [4] ANÁLISIS EXPLORATORIO DE DATOS (EDA)
# ----------------------------------------------------------------------------
print(df.describe())
print("\nValores nulos por columna:\n", df.isnull().sum())

mensual = df.groupby("mes")["turistas"].mean()
plt.figure(figsize=(8, 4))
plt.bar(mensual.index, mensual.values, color="#2E7D6B")
plt.title("Promedio histórico de turistas por mes (2019-2024)")
plt.xlabel("Mes"); plt.ylabel("Turistas/día (promedio)")
plt.show()

# %% [5] LIMPIEZA Y TRATAMIENTO DE VALORES NULOS
# ----------------------------------------------------------------------------
# El dataset no presenta valores nulos estructurales; sin embargo, se aplica
# un paso preventivo de imputación dentro del pipeline (celda 7) para que el
# sistema sea robusto ante datos reales incompletos en producción.
outliers_iqr = df["turistas"].quantile(0.75) - df["turistas"].quantile(0.25)
lim_superior = df["turistas"].quantile(0.75) + 1.5 * outliers_iqr
print(f"Límite superior IQR para outliers: {lim_superior:.0f} turistas/día")
print(f"Registros por encima del límite: {(df['turistas'] > lim_superior).sum()} "
      "(se conservan: corresponden a festividades reales de alta demanda)")

# %% [6] DIVISIÓN ENTRENAMIENTO / PRUEBA (temporal, evita fuga de información)
# ----------------------------------------------------------------------------
FEATURES_NUM = ["anio", "mes", "dia_semana", "es_fin_semana", "es_festividad",
                 "temperatura_c", "precipitacion_mm"]
FEATURES_CAT = ["temporada"]
TARGET = "turistas"

mask_train = df["anio"] <= 2023
X_train = df.loc[mask_train, FEATURES_NUM + FEATURES_CAT]
X_test = df.loc[~mask_train, FEATURES_NUM + FEATURES_CAT]
y_train = df.loc[mask_train, TARGET]
y_test = df.loc[~mask_train, TARGET]

print(f"Entrenamiento: {len(X_train)} días (2019-2023)")
print(f"Prueba: {len(X_test)} días (2024, no visto durante el entrenamiento)")

# %% [7] PREPROCESAMIENTO (ColumnTransformer: imputación + codificación)
# ----------------------------------------------------------------------------
preprocesador = ColumnTransformer([
    ("num", SimpleImputer(strategy="median"), FEATURES_NUM),
    ("cat", Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ]), FEATURES_CAT),
])

# %% [8] ENTRENAMIENTO Y AJUSTE DE HIPERPARÁMETROS — RANDOM FOREST
# ----------------------------------------------------------------------------
pipe_rf = Pipeline([("prep", preprocesador),
                     ("model", RandomForestRegressor(random_state=42))])
grid_rf = {"model__n_estimators": [200, 400], "model__max_depth": [8, 12, None]}
gs_rf = GridSearchCV(pipe_rf, grid_rf, cv=3, scoring="neg_mean_absolute_error", n_jobs=-1)
gs_rf.fit(X_train, y_train)
print("Mejores hiperparámetros Random Forest:", gs_rf.best_params_)

# %% [9] ENTRENAMIENTO Y AJUSTE DE HIPERPARÁMETROS — GRADIENT BOOSTING
# ----------------------------------------------------------------------------
pipe_gb = Pipeline([("prep", preprocesador),
                     ("model", GradientBoostingRegressor(random_state=42))])
grid_gb = {"model__n_estimators": [200, 300], "model__learning_rate": [0.05, 0.1],
           "model__max_depth": [3, 4]}
gs_gb = GridSearchCV(pipe_gb, grid_gb, cv=3, scoring="neg_mean_absolute_error", n_jobs=-1)
gs_gb.fit(X_train, y_train)
print("Mejores hiperparámetros Gradient Boosting:", gs_gb.best_params_)

# %% [10] ENTRENAMIENTO — XGBOOST
# ----------------------------------------------------------------------------
pipe_xgb = Pipeline([("prep", preprocesador),
                      ("model", XGBRegressor(random_state=42, n_estimators=300,
                                              max_depth=4, learning_rate=0.08,
                                              subsample=0.9, colsample_bytree=0.9,
                                              objective="reg:squarederror"))])
pipe_xgb.fit(X_train, y_train)

# %% [11] EVALUACIÓN Y COMPARACIÓN DE MODELOS
# ----------------------------------------------------------------------------
def evaluar(nombre, modelo):
    pred = modelo.predict(X_test)
    mae = mean_absolute_error(y_test, pred)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    r2 = r2_score(y_test, pred)
    print(f"{nombre:20s} | MAE={mae:7.1f} | RMSE={rmse:7.1f} | R²={r2:.3f}")
    return {"modelo": modelo, "pred": pred, "mae": mae, "rmse": rmse, "r2": r2}

resultados = {
    "Random Forest": evaluar("Random Forest", gs_rf.best_estimator_),
    "Gradient Boosting": evaluar("Gradient Boosting", gs_gb.best_estimator_),
    "XGBoost": evaluar("XGBoost", pipe_xgb),
}
mejor_nombre = min(resultados, key=lambda k: resultados[k]["mae"])
mejor_modelo = resultados[mejor_nombre]["modelo"]
print(f"\nModelo seleccionado: {mejor_nombre}")

# %% [12] GRÁFICOS DE EVALUACIÓN
# ----------------------------------------------------------------------------
pred_final = resultados[mejor_nombre]["pred"]

plt.figure(figsize=(6, 5))
plt.scatter(y_test, pred_final, alpha=0.4, color="#3B5BA5")
lims = [0, max(y_test.max(), pred_final.max())]
plt.plot(lims, lims, "--", color="black")
plt.xlabel("Turistas reales"); plt.ylabel("Turistas predichos")
plt.title(f"Real vs. predicho — {mejor_nombre}")
plt.show()

df_test = df.loc[~mask_train].copy().sort_values("fecha")
df_test["prediccion"] = pred_final
plt.figure(figsize=(11, 4))
plt.plot(df_test["fecha"], df_test["turistas"], label="Real")
plt.plot(df_test["fecha"], df_test["prediccion"], label="Predicho", alpha=0.8)
plt.legend(); plt.title("Demanda real vs. predicha — 2024")
plt.show()

# %% [13] PREDICCIÓN SOBRE NUEVOS DATOS (ejemplo)
# ----------------------------------------------------------------------------
nuevo_dato = pd.DataFrame([{
    "anio": 2026, "mes": 2, "dia_semana": 5, "es_fin_semana": 1,
    "es_festividad": 1, "temperatura_c": 9.0, "precipitacion_mm": 5.0,
    "temporada": "Baja",
}])
prediccion_nueva = mejor_modelo.predict(nuevo_dato)
print(f"\nPredicción para un sábado de festividad de la Candelaria (feb 2026): "
      f"{prediccion_nueva[0]:.0f} turistas estimados")

# %% [14] SERIALIZACIÓN DEL MODELO (para la app Streamlit)
# ----------------------------------------------------------------------------
joblib.dump(mejor_modelo, "modelo_xgboost.pkl")
print("Modelo guardado como modelo_xgboost.pkl")
# En Colab, descarga el archivo con:
# from google.colab import files
# files.download("modelo_xgboost.pkl")
