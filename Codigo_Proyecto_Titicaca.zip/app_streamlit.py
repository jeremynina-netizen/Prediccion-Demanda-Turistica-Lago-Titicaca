# -*- coding: utf-8 -*-
"""
============================================================================
 APP STREAMLIT — Predicción de Demanda Turística del Lago Titicaca
============================================================================
Autor: Jeremy Rodrigo Nina Arias (código 261232)

Ejecutar localmente con:
    streamlit run app_streamlit.py

Requiere que exista el archivo "modelo_xgboost.pkl" (generado por el
notebook de Colab) en la misma carpeta que este script. Si el archivo no
existe, la app entrena un modelo de respaldo rápido con datos simulados
para que la demo funcione igualmente.
============================================================================
"""

import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Predicción de Demanda Turística — Lago Titicaca",
    page_icon="🏔️",
    layout="centered",
)

MODEL_PATH = os.path.join(os.path.dirname(__file__), "modelo_xgboost.pkl")


@st.cache_resource
def cargar_modelo():
    """Carga el modelo entrenado (.pkl). Si no existe, entrena uno rápido
    de respaldo con datos simulados, únicamente para fines de demostración."""
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH), True

    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.ensemble import GradientBoostingRegressor

    np.random.seed(42)
    fechas = pd.date_range("2019-01-01", "2024-12-31", freq="D")
    n = len(fechas)
    df = pd.DataFrame({"fecha": fechas})
    df["anio"] = df["fecha"].dt.year
    df["mes"] = df["fecha"].dt.month
    df["dia_semana"] = df["fecha"].dt.dayofweek
    df["es_fin_semana"] = df["dia_semana"].isin([5, 6]).astype(int)
    estacionalidad = {1: .85, 2: .55, 3: .55, 4: .6, 5: .7, 6: .95, 7: 1.15,
                       8: 1.1, 9: .85, 10: .75, 11: .75, 12: 1.05}
    df["factor"] = df["mes"].map(estacionalidad)
    df["es_festividad"] = np.random.rand(n) < 0.03
    df["temperatura_c"] = df["mes"].map({1: 9.5, 2: 9.3, 3: 9, 4: 8, 5: 5.5,
                                          6: 3, 7: 2.5, 8: 4, 9: 6.5, 10: 8.5,
                                          11: 9.5, 12: 9.8}) + np.random.normal(0, 1.3, n)
    df["precipitacion_mm"] = np.clip(np.random.gamma(1.5, 3, n) - 3, 0, None)
    df["temporada"] = df["mes"].map({1: "Alta", 2: "Baja", 3: "Baja", 4: "Baja",
                                      5: "Media", 6: "Alta", 7: "Alta", 8: "Alta",
                                      9: "Media", 10: "Media", 11: "Media", 12: "Alta"})
    df["turistas"] = np.clip(850 * df["factor"] * (1 + .35 * df["es_fin_semana"])
                              * (1 + .9 * df["es_festividad"])
                              * np.random.normal(1, .12, n), 20, None)

    features_num = ["anio", "mes", "dia_semana", "es_fin_semana", "es_festividad",
                     "temperatura_c", "precipitacion_mm"]
    prep = ColumnTransformer([
        ("num", "passthrough", features_num),
        ("cat", OneHotEncoder(handle_unknown="ignore"), ["temporada"]),
    ])
    pipe = Pipeline([("prep", prep), ("model", GradientBoostingRegressor(random_state=42))])
    pipe.fit(df[features_num + ["temporada"]], df["turistas"])
    return pipe, False


modelo, es_modelo_real = cargar_modelo()

# ---------------------------------------------------------------------------
# Encabezado
# ---------------------------------------------------------------------------
st.title("🏔️ Predicción de Demanda Turística — Lago Titicaca")
st.markdown(
    "Sistema de apoyo a la planificación turística basado en **Machine Learning** "
    "(XGBoost / Gradient Boosting). Ingresa las variables del día que deseas "
    "estimar y el modelo predecirá el número aproximado de turistas."
)
if not es_modelo_real:
    st.info(
        "⚠️ No se encontró `modelo_xgboost.pkl` en esta carpeta: se está usando "
        "un modelo de respaldo entrenado en caliente solo para la demostración. "
        "Genera el modelo real ejecutando el notebook de Google Colab."
    )

st.divider()

# ---------------------------------------------------------------------------
# Formulario de entrada
# ---------------------------------------------------------------------------
col1, col2 = st.columns(2)

with col1:
    mes = st.selectbox(
        "Mes", list(range(1, 13)),
        format_func=lambda m: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                                "Julio", "Agosto", "Septiembre", "Octubre",
                                "Noviembre", "Diciembre"][m - 1],
        index=6,
    )
    dia_semana_lbl = st.selectbox(
        "Día de la semana",
        ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
        index=5,
    )
    anio = st.number_input("Año a predecir", min_value=2024, max_value=2030, value=2026)
    temporada = st.selectbox("Temporada turística", ["Alta", "Media", "Baja"], index=0)

with col2:
    temperatura = st.slider("Temperatura media estimada (°C)", -5.0, 20.0, 8.0, 0.5)
    precipitacion = st.slider("Precipitación estimada (mm)", 0.0, 40.0, 0.0, 1.0)
    es_festividad = st.checkbox("¿Es una fecha de festividad regional? "
                                 "(Candelaria, Fiestas Patrias, aniversario de Puno, etc.)")

dia_semana_map = {"Lunes": 0, "Martes": 1, "Miércoles": 2, "Jueves": 3,
                   "Viernes": 4, "Sábado": 5, "Domingo": 6}
dia_semana = dia_semana_map[dia_semana_lbl]
es_fin_semana = int(dia_semana in [5, 6])

st.divider()

if st.button("🔮 Predecir demanda turística", type="primary", use_container_width=True):
    entrada = pd.DataFrame([{
        "anio": anio, "mes": mes, "dia_semana": dia_semana,
        "es_fin_semana": es_fin_semana, "es_festividad": int(es_festividad),
        "temperatura_c": temperatura, "precipitacion_mm": precipitacion,
        "temporada": temporada,
    }])

    prediccion = modelo.predict(entrada)[0]
    prediccion = max(0, round(prediccion))

    st.subheader("Resultado de la predicción")
    st.metric("Turistas estimados para ese día", f"{prediccion:,}".replace(",", " "))

    if prediccion > 1300:
        st.warning(
            "📈 Demanda alta prevista: se recomienda reforzar embarcaciones, "
            "personal de guiado y coordinación con capitanía de puerto."
        )
    elif prediccion < 300:
        st.info(
            "📉 Demanda baja prevista: considerar optimizar turnos de "
            "embarcaciones y personal disponible."
        )
    else:
        st.success("✅ Demanda dentro del rango habitual de operación.")

st.divider()
st.caption(
    "Proyecto académico — Curso de Introducción a la Inteligencia Artificial. "
    "Las predicciones se basan en un modelo entrenado con datos históricos "
    "simulados de forma estadísticamente informada; deben interpretarse como "
    "una estimación de apoyo a la planificación, no como un valor exacto."
)
